RUANGKARYA ANDROID - VERSI EDITOR DOKUMEN LENGKAP

Fitur:
- Search Google di dalam aplikasi.
- Design Studio dengan ekspor PNG.
- Editor dokumen: font, ukuran teks, bold, italic, underline, coret, warna teks, stabilo, heading, perataan paragraf, bullet, numbering, tabel, pemisah halaman, ukuran kertas A4/Letter, margin.
- Ekspor TXT, HTML, Word-compatible .DOC, dan cetak/simpan PDF melalui dialog cetak perangkat.

Catatan format:
Ekspor Word saat ini menggunakan format .doc berbasis HTML yang kompatibel dengan Microsoft Word dan aplikasi pengolah kata umum; belum berupa .docx native. PDF dibuat melalui fitur cetak/simpan PDF perangkat.

Membuat APK:
1. Buka folder proyek ini dengan Android Studio.
2. Tunggu Gradle Sync dan instal Android SDK yang diminta.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug ada di app/build/outputs/apk/debug/app-debug.apk.
